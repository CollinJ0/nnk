#!/usr/bin/env python
# filename: errors.py

EC1='Input Twist Bio Excel file is incorrectly formatted: Error code 1'
EC2='Input Twist Bio Excel file is incorrectly formatted: Error code 2'
EC3="Input Twist Bio Excel file is incorrectly formatted: Error code 3"
RUNIQUE=("No, you are trying to assign {} to a variants object "
         "that is {}.\nVariants property {}.unique remains {}")