#!/usr/bin/env python
# filename: count_variants.py
