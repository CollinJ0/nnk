#!/usr/bin/env python
# filename: alignment.py