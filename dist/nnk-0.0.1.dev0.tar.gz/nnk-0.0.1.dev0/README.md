# nnk
Tools for counting "NNK" variants from a yeast display library and downstream analysis.