#!/usr/bin/env python
# filename: library.py